class UserNotLoggedIn(Exception):
    STATUS_CODE = -7