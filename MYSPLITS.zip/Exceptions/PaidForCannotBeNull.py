class PaidForCannotBeNull(Exception):
    STATUS_CODE = -13