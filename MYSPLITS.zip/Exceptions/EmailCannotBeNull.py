class EmailCannotBeNull (Exception):
    STATUS_CODE = -5