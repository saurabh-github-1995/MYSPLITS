class UserNameCannotBeNull(Exception):
    STATUS_CODE = -4
