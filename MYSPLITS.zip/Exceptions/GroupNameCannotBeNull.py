class GroupNameCannotBeNull(Exception):
    STATUS_CODE = -8