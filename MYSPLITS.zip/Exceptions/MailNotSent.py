class MailNotSent(Exception):
    pass
