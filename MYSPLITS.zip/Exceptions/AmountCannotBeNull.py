class AmountCannotBeNull(Exception):
    STATUS_CODE = -12