class WrongCredentials(Exception):
    STATUS_CODE = -6