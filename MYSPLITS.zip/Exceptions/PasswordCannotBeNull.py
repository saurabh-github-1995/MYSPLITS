class PasswordCannotBeNull(Exception):
    STATUS_CODE = -14