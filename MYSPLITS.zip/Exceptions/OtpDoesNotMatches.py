class OtpDoesNotMatches(Exception):
    STATUS_CODE = -16
