class UserDoesNotExists(Exception):
    STATUS_CODE = -10