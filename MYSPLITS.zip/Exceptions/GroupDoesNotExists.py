class GroupDoesNotExists(Exception):
    STATUS_CODE = -9