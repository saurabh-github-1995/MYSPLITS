class InviteDoesNotExists(Exception):
    STATUS_CODE = -11