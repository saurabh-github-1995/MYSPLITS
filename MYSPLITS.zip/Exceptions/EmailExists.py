class EmailExists(Exception):
    STATUS_CODE = -3