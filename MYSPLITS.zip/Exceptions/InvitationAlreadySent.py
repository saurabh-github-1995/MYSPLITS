class InvitationAlreadySent(Exception):
    STATUS_CODE = -15