class UserNameExists(Exception):
    STATUS_CODE = -2
